for i in {89..90}
do
grep 'cm-1' OUTCAR-V$i >> sp_5.txt
done
